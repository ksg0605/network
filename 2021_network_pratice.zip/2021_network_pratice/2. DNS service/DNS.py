import requests
class DNSClient:
    def __init__(self):
        self.url = "http://127.0.0.1:10000"
        
    def register(self, domain, ip):
        params = {"domain":domain, "ip":ip}
        url = self.url+"/register"
        return requests.get(url=url, params = params)
    
    def get(self, domain):
        params = {"domain":domain}
        url = self.url+"/get"
        return requests.get(url=url, params = params).text
    
    def delete(self, domain):
        params = {"domain":domain}
        url = self.url+"/delete"
        return requests.get(url=url, params = params)